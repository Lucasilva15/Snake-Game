const canvas = document.getElementById("tela");
//Contexto
const ctx = canvas.getContext("2d");

class Rastro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
}

// Malha da Tela
var qdq = 19;
//Tamanha dos quadrados
var tamanho = canvas.width / qdq - 2;

var cobra = {
  x: Math.floor(Math.random() * qdq),
  y: Math.floor(Math.random() * qdq),
  rastro: [],
  cauda: 2,
  cor: 'orange',
  vel: 7
}

var apple = {
  x: Math.floor(Math.random() * qdq),
  y: Math.floor(Math.random() * qdq),
  cor: 'red'
}

//Direção x e y da cobra
var inXVel = 0;
var inYVel = 0;

//Velocidade x e y da cobra
var xVel = 0;
var yVel = 0;

var score = 0;
var best = "Best:";

const butpres = new Audio("./assets/button-press.mp3");
const point = new Audio("./assets/point.mp3");
const gulp = new Audio("./assets/gulp.mp3");
const over = new Audio("./assets/hit.mp3");
const musica_game = new Audio("./assets/music_game_snow.mp3");

//game loop
function Game() {
  xVel = inXVel;
  yVel = inYVel;

  if (getBest() < score) {
    setBest(score);
  }

  posicaocobra();
  let resultado = GameOver();
  if (resultado) {
    return;
  }

  //Tela
  fundo();

  Colisao();
  Apple();
  Cobra();

  Titulo();
  Score();
  Best();
  //musica_game.play();

  if (score == 19) {
    cobra.vel = 8;
  }
  if (score == 20) {
    cobra.vel = 9;
  }
  if (score == 30) {
    cobra.vel = 10;
  }
  if (score == 40) {
    cobra.vel = 11;
  }
  if (score == 50) {
    cobra.vel = 12;
  }

  //Verificação se a maçã está nascendo dentro da cobra
  for (let i = 0; i < cobra.rastro.length; i++) {
    let parte = cobra.rastro[i];
    if (apple.x == parte.x && apple.y == parte.y) {
      apple.x = Math.floor(Math.random() * qdq);
      apple.y = Math.floor(Math.random() * qdq);
      gulp.play();
    }
  }

  setTimeout(Game, 1000 / cobra.vel);
}

function GameOver() {
  let GameOver = false;

  if (yVel == 0 && xVel == 0) {
    return GameOver;
  }

  //Paredes
  if (cobra.x < 0) {
    GameOver = true;
    over.play();
    //musica_game.pause();
    delete fundo();
  } else if (cobra.x == qdq) {
    GameOver = true;
    over.play();
    //musica_game.pause();
    delete fundo();
  } else if (cobra.y < 0) {
    GameOver = true;
    over.play();
    //musica_game.pause();
    delete fundo();
  } else if (cobra.y == qdq) {
    GameOver = true;
    over.play();
    //musica_game.pause();
    delete fundo();
  }

  for (let i = 0; i < cobra.rastro.length; i++) {
    let parte = cobra.rastro[i];
    if (parte.x == cobra.x && parte.y == cobra.y) {
      GameOver = true;
      over.play();
      //musica_game.pause();
      delete fundo();
    }
  }

  if (GameOver) {
    ctx.fillStyle = "white";
    ctx.font = "50px pixelfont";

    //Pintando o nome Game Over
    let nomeGameOver = ctx.createLinearGradient(0, 0, canvas.width, 0);
    nomeGameOver.addColorStop("0.2", " magenta");
    nomeGameOver.addColorStop("0.6", "blue");
    nomeGameOver.addColorStop("1.0", "red");

    //Criando o nome Game over
    ctx.fillStyle = nomeGameOver;
    ctx.fillText("Game Over!", canvas.width / 4, canvas.height / 2);
  }
  return GameOver;
}

function getBest() {
  return window.localStorage.getItem(best) || 0;
}

function setBest(score) {
  window.localStorage.setItem(best, score);
}

function Best() {
  ctx.fillStyle = "#E5E7FF";
  ctx.font = "15pt pixelfont";
  ctx.fillText("Best: " + getBest(), canvas.width - 70, 17.5);
}

function Score() {
  ctx.fillStyle = "#E5E7FF";
  ctx.font = "15pt pixelfont";
  ctx.fillText("Score: " + score, canvas.width - 355, 17.5);
}

function Titulo() {
  ctx.fillStyle = "lime";
  ctx.font = "16pt pixelfont";
  ctx.fillText("Snake Game", canvas.width / 2 - 40, 17.5);
}

function fundo() {
  let cor = ctx.createLinearGradient(0, 0, canvas.width, 0);
  cor.addColorStop("0.2", " magenta");
  cor.addColorStop("0.6", "blue");
  cor.addColorStop("1.0", "red");

  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = cor;
  ctx.strokeRect(0, 0, canvas.width, canvas.height - 1)
}

function Cobra() {
  //Rastro ou Cauda
  ctx.fillStyle = 'lime';
  for (let i = 0; i < cobra.rastro.length; i++) {
    let parte = cobra.rastro[i];
    ctx.fillRect(parte.x * qdq, parte.y * qdq, tamanho, tamanho);
  }
  
  cobra.rastro.push(new Rastro(cobra.x, cobra.y));
  /*if (cobra.rastro.length > cobra.cauda) {
    cobra.rastro.shift();
  }*/
  while (cobra.rastro.length > cobra.cauda) {
    cobra.rastro.shift();
  }

  //Cabeça 
  ctx.fillStyle = cobra.cor;
  ctx.fillRect(cobra.x * qdq, cobra.y * qdq, tamanho, tamanho);
}

function posicaocobra() {
  cobra.x += xVel;
  cobra.y += yVel;
}

function Apple() {
  ctx.fillStyle = apple.cor;
  ctx.fillRect(apple.x * qdq, apple.y * qdq, tamanho, tamanho);
}

function Colisao() {
  if (cobra.x == apple.x && cobra.y == apple.y) {
    apple.x = Math.floor(Math.random() * qdq);
    apple.y = Math.floor(Math.random() * qdq);
    cobra.cauda++;
    score++;
    point.play();
  }
}

function key(event) {
  //Cima
  if (event == 38) {
    butpres.play();
    if (inYVel == 1) return;
    inYVel = -1;
    inXVel = 0;
  }

  //Baixo
  if (event == 40) {
    butpres.play();
    if (inYVel == -1) return;
    inYVel = 1;
    inXVel = 0;
  }

  //Direita
  if (event == 37) {
    butpres.play();
    if (inXVel == 1) return;
    inYVel = 0;
    inXVel = -1;
  }

  //Esquerda
  if (event == 39) {
    butpres.play();
    if (inXVel == -1) return;
    inYVel = 0;
    inXVel = 1;
  }
}

function update() {
  document.location.reload();
}

window.addEventListener("load", Game);
